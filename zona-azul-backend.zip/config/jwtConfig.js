module.exports = {
    key : 'chave', 
    //in case i need it in multiple places to decode tokens, if anyone decides to change it, this is a master reference
}